<?php

 class Classe_client
{
public $cin;
public $nom;
public $prenom;
public $adresse;

public function __construct($cin, $nom, $prenom, $adresse){
    $this->cin = $cin;
    $this->nom = $nom;
    $this->prenom = $prenom;
    $this->adresse = $adresse;
}

public function afficher(){
    echo $this->cin." ".$this->nom." ".$this->prenom." ".$this->adresse."<br>";
}

public function __destruct(){
    echo "Destructeur";
}


}

?>