<?php
$host='localhost';
$user='root';
$mot_de_passe='';
$nomBD='BDD_res';
try {
    $connexion=new PDO('mysql:host='.$host.';dbname='.$nomBD,$user,$mot_de_passe);
} catch (Exception $e) {
   echo "error". $e->getMessage();
   echo " N° ".$e->getCode();
}



?>