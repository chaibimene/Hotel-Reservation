<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faire une Réservation</title>
  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="#">Votre Logo</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="container mt-5">
        <h1 class="text-center">Faire une Réservation</h1>
        <div class="row justify-content-center mt-5">
            <div class="col-md-4">
                <form method="post" action="chambreDispo.php">
                    <div class="form-group">
                        <label for="cin">CIN:</label>
                        <input type="text" class="form-control" id="cin" name="cin" required>
                    </div>
                    <div class="form-group">
                        <label for="typeChambre">Type de Chambre:</label>
                        <select class="form-control" id="typeChambre" name="typeChambre" required>
                            <option value="single">Single</option>
                            <option value="double">Double</option>
                            <option value="triple">Triple</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="dateArrivee">Date d'Arrivée:</label>
                        <input type="date" class="form-control" id="dateArrivee" name="dateArrivee" required>
                    </div>
                    <div class="form-group">
                        <label for="dateDepart">Date de Départ:</label>
                        <input type="date" class="form-control" id="dateDepart" name="dateDepart" required>
                    </div>
                    <button type="submit" class="btn btn-primary btn-block">Voir les chambres disponibles</button>
                </form>
            </div>
        </div>
    </div>

   
</body>
</html>
