<?php
session_start();
include 'connexion.php';

if (!isset($_SESSION['cin'])) {
    header("Location: signin.php");
    exit();
}

$cin = $_SESSION['cin'];
$sql = "SELECT * FROM Reservation WHERE cin='$cin'";
$result = $connexion->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes Réservations</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <p class="navbar-brand" href="#">The Perfect VACAY</p>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="container mt-5">
        <h1 class="text-center">Mes Réservations</h1>
        <div class="mt-5">
        <?php
            if ($result) {
                $reservations = $result->fetchAll(PDO::FETCH_ASSOC);
                if (!empty($reservations)) {
                    foreach ($reservations as $reservation) {
                        echo "<div class='card mb-3'>";
                        echo "<div class='card-body'>";
                        echo "<h5 class='card-title'>Numéro de Réservation: " . htmlspecialchars($reservation["numReservation"]) . "</h5>";
                        echo "<p class='card-text'>Numéro de Chambre: " . htmlspecialchars($reservation["numChambre"]) . "</p>";
                        echo "<p class='card-text'>Date d'Arrivée: " . htmlspecialchars($reservation["dateArrivee"]) . "</p>";
                        echo "<p class='card-text'>Date de Départ: " . htmlspecialchars($reservation["dateDepart"]) . "</p>";
                        echo "</div>";
                        echo "</div>";
                    }
                } else {
                    echo "<p>Aucune réservation trouvée.</p>";
                }
            } else {
                echo "<p>Erreur lors de la récupération des réservations.</p>";
            }
            ?>
        </div>
    </div>

    

    
    
</body>
</html>

