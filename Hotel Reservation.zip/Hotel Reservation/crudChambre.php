<?php
session_start();
include 'connexion.php';
include 'Classe_chambre.php';

if (!isset($_SESSION['admin'])) {
    header("Location: espaceExtranet.php");
    exit();
}

// add chambre
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "add") {
    $numChambre = $_POST['numChambre'];
    $type = $_POST['type'];
    $prix = $_POST['prix'];

   
    $sql="INSERT INTO Chambre (numChambre,type, prix) VALUES('$numChambre', '$type', '$prix')";
    $result = $connexion->query($sql);
    if ($connexion->exec($sql) === TRUE){
        echo "Chambre ajoutée avec succès!";
    } else {
        echo "Erreur lors de l'ajout de la chambre.";
    }
}

// update chambre
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "edit") {
    $numChambre = $_POST['numChambre'];
    $type = $_POST['type'];
    $prix = $_POST['prix'];

    $sql = "UPDATE Chambre SET type='$type', prix='$prix' WHERE numChambre='$numChambre'";
    $result = $connexion->query($sql);
    if ($connexion->query($sql) === TRUE) {
        echo "Chambre modifiée avec succès!";
    } else {
        echo "Erreur lors de la modification de la chambre.";
    }
}

// supp chambre
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "delete") {
    $numChambre = $_POST['numChambre'];

    $sql = "DELETE FROM Chambre WHERE numChambre='$numChambre'";
    if ($connexion->query($sql) === TRUE) {
        echo "Chambre supprimée avec succès!";
    } else {
        echo "Erreur lors de la suppression de la chambre.";
    }
}

//getting all the rooms
$sql = "SELECT * FROM Chambre";
$result = $connexion->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer Chambres</title>
  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="#">Votre Logo</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="container mt-5">
        <h1 class="text-center">Gérer Chambres</h1>

        <div class="row mt-5">
            <div class="col-md-4">
                <form method="post" action="crudChambre.php">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label for="numChambre">Numéro de Chambre:</label>
                        <input type="text" class="form-control" id="numChambre" name="numChambre">
                    </div>
                    <div class="form-group">
                        <label for="type">Type:</label>
                        <input type="text" class="form-control" id="type" name="type">
                    </div>
                    <div class="form-group">
                        <label for="prix">Prix:</label>
                        <input type="text" class="form-control" id="prix" name="prix">
                    </div>
                    <button type="submit" class="btn btn-primary">Ajouter Chambre</button>
                </form>
            </div>
            <div class="col-md-4">
                <form method="post" action="crudChambre.php">
                    <input type="hidden" name="action" value="edit">
                    <div class="form-group">
                        <label for="numChambre">Numéro de Chambre:</label>
                        <input type="text" class="form-control" id="numChambre" name="numChambre">
                    </div>
                    <div class="form-group">
                        <label for="type">Type:</label>
                        <input type="text" class="form-control" id="type" name="type">
                    </div>
                    <div class="form-group">
                        <label for="prix">Prix:</label>
                        <input type="text" class="form-control" id="prix" name="prix">
                    </div>
                    <button type="submit" class="btn btn-success">Modifier Chambre</button>
                </form>
            </div>
            <div class="col-md-4">
                <form method="post" action="crudChambre.php">
                    <input type="hidden" name="action" value="delete">
                    <div class="form-group">
                        <label for="numChambre">Numéro de Chambre:</label>
                        <input type="text" class="form-control" id="numChambre" name="numChambre">
                    </div>
                    <button type="submit" class="btn btn-danger">Supprimer Chambre</button>
                </form>
            </div>
        </div>

        <hr class="mt-5">

        <h2>Liste des Chambres</h2>
        <div class="table-responsive">
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th>Numéro de Chambre</th>
                        <th>Type</th>
                        <th>Prix</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $chambres = $result->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($chambres as $chambre) {
                        echo "<tr>";
                        echo "<td>" . $chambre["numChambre"] . "</td>";
                        echo "<td>" . $chambre["type"] . "</td>";
                        echo "<td>" . $chambre["prix"] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <div class="text-center mt-5">
            <button class="btn btn-primary" onclick="location.href='bienvenueAdmin.php'">Revenir à la page Admin</button>
        </div>
    </div>

    <footer class="bg-dark text-light py-4">
        <div class="container">
            <p class="text-center">© 2024 The Perfect VACAY . Tous droits réservés.</p>
        </div>
    </footer>
   
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

