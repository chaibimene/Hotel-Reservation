<?php

class Classe_reservation
{
    public $numReservation;
    public $cin;
    public $numChambre;
    public $dateArrivee;
    public $dateDepart;

    public function __construct($numReservation, $cin, $numChambre, $dateArrivee, $dateDepart)
    {
        $this->numReservation = $numReservation;
        $this->cin = $cin;
        $this->numChambre = $numChambre;
        $this->dateArrivee = $dateArrivee;
        $this->dateDepart = $dateDepart;
    }


}
?>