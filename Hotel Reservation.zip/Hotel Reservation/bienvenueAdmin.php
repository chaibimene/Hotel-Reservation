<?php
session_start();

if (!isset($_SESSION['admin'])) {
    header("Location: espaceExtranet.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bienvenue Admin</title>
  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="#">The Perfect VACAY</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">Accueil</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-5">
        <div class="text-center">
            <h1>Bienvenue Admin</h1>
        </div>
        <div class="row mt-5">
            <div class="col-md-4">
                <button class="btn btn-primary btn-block" onclick="location.href='crudClient.php'">Gérer Clients</button>
            </div>
            <div class="col-md-4">
                <button class="btn btn-success btn-block" onclick="location.href='crudReservation.php'">Gérer Réservations</button>
            </div>
            <div class="col-md-4">
                <button class="btn btn-danger btn-block" onclick="location.href='crudChambre.php'">Gérer Chambres</button>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-12">
                <button class="btn btn-secondary btn-block" onclick="location.href='logout.php'">Déconnecter</button>
            </div>
        </div>
    </div>
   
</body>
</html>

