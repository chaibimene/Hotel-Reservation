<?php
include 'connexion.php';
include 'Classe_reservation.php';
include 'Classe_chambre.php';
include 'Classe_client.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $cin = $_POST['cin'];
    $typeChambre = $_POST['typeChambre'];
    $dateArrivee = $_POST['dateArrivee'];
    $dateDepart = $_POST['dateDepart'];

    // search chambre dispo
    $sql = "SELECT * FROM Chambre 
            WHERE type='$typeChambre' 
            AND numChambre NOT IN (
                SELECT numChambre FROM Reservation 
                WHERE (dateArrivee <= '$dateDepart' AND dateDepart >= '$dateArrivee')
            )";
    $resultat = $connexion->query($sql);
}
//insert reservation

if ($_SERVER["REQUEST_METHOD"] == "POST" ) {
    $cin = $_POST['cin'];
    $typeChambre = $_POST['typeChambre'];
    $dateArrivee = $_POST['dateArrivee'];
    $dateDepart = $_POST['dateDepart'];
  
  
   
    
    $sql = "INSERT INTO Reservation ( cin, numChambre,typeChambre, dateArrivee, dateDepart) VALUES ( '$cin','$numChambre','$typeChambre', '$dateArrivee', '$dateDepart')";
     $result = $connexion->exec($sql);
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chambres Disponibles</title>
 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Chambres Disponibles</h1>
        <form method="post" action="facture.php">
    <div class="form-group">
        <label for="cin">CIN:</label>
        <input type="text" class="form-control" id="cin" name="cin" value="<?php echo htmlspecialchars($cin); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="typeChambre">Type de Chambre:</label>
        <input type="text" class="form-control" id="typeChambre" name="typeChambre" value="<?php echo htmlspecialchars($typeChambre); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="dateArrivee">Date d'Arrivée:</label>
        <input type="text" class="form-control" id="dateArrivee" name="dateArrivee" value="<?php echo htmlspecialchars($dateArrivee); ?>" readonly>
    </div>
    <div class="form-group">
        <label for="dateDepart">Date de Départ:</label>
        <input type="text" class="form-control" id="dateDepart" name="dateDepart" value="<?php echo htmlspecialchars($dateDepart); ?>" readonly>
    </div>
    <input type="submit" class="btn btn-primary" value="Voir les chambres disponibles">
</form>


        <?php
        //if fama resultat
    if ($resultat) {
        // if fama des chambres
        if ($resultat->rowCount() > 0) {
            // affichage
            $chambres = $resultat->fetchAll(PDO::FETCH_ASSOC);
            echo "<form method='post'>";
            echo "<ul class='list-group'>";
            foreach ($chambres as $row) {
                echo "<li class='list-group-item'>";
                echo "Chambre numéro: " . $row['numChambre'];
                echo " - <input type='radio' name='numChambre' value='" . $row['numChambre'] . "' required>";
                echo "</li>";
            }
            echo "</ul>";
            echo "<form>";
           echo  "<button class='btn btn-primary' onclick='location.href='facture.php''>Confirmer La eservation</button>";
        } else {
     
            echo "Aucune chambre disponible pour les dates spécifiées.";
        }
    } 

            ?>
      
    </div>

   
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>