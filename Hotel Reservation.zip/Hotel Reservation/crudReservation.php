<?php
include 'Classe_reservation.php';
include 'Classe_chambre.php';
include 'Classe_client.php';
include 'connexion.php';
//insert reservation

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "add") {
    $cin = $_POST['cin'];
    $typeChambre = $_POST['typeChambre'];
    $dateArrivee = $_POST['dateArrivee'];
    $dateDepart = $_POST['dateDepart'];
  
    $numChambre = $_POST['numChambre'];
   
    
    $sql = "INSERT INTO Reservation ( cin, numChambre,typeChambre, dateArrivee, dateDepart) VALUES ( '$cin','$numChambre','$typeChambre', '$dateArrivee', '$dateDepart')";
     $result = $connexion->exec($sql);
}

// update reservation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "edit") {
   
    $cin = $_POST['cin'];
    $typeChambre = $_POST['typeChambre'];
    $dateArrivee = $_POST['dateArrivee'];
    $dateDepart = $_POST['dateDepart'];
    $numChambre = $_POST['numChambre'];

    $sql = "UPDATE Reservation SET cin='$cin', typeChambre='$typeChambre', dateArrivee='$dateArrivee', dateDepart='$dateDepart',numChambre='$numChambre' WHERE numReservation='$numReservation'";
    $result = $connexion->query($sql);
}

// supprimer reserv
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "delete") {
    $numReservation = $_POST['numReservation'];

    $sql = "DELETE FROM Reservation WHERE numReservation='$numReservation'";
    $result = $connexion->query($sql);
}

// getting les reservation
$sql = "SELECT * FROM Reservation";
$result = $connexion->query($sql);


?>
<!DOCTYPE html> 
<html lang="fr"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Gérer les Réservations</title> 

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css"> 
</head> 
<body> 
    <header> 
        <nav class="navbar navbar-expand-lg navbar-light bg-light"> 
            <div class="container"> 
                <a class="navbar-brand" href="#">Votre Logo</a> 
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation"> 
                    <span class="navbar-toggler-icon"></span> 
                </button> 
                <div class="collapse navbar-collapse" id="navbarNav"> 
                    <ul class="navbar-nav ml-auto"> 
                        <li class="nav-item active"> 
                            <a class="nav-link" href="#">Accueil</a> 
                        </li> 
                        <li class="nav-item"> 
                            <a class="nav-link" href="#">Services</a> 
                        </li> 
                        <li class="nav-item"> 
                            <a class="nav-link" href="#">Contact</a> 
                        </li> 
                    </ul> 
                </div> 
            </div> 
        </nav> 
    </header> 
 
    <div class="container mt-5"> 
        <h1 class="text-center">Gérer les Réservations</h1> 
 
        <h2 class="mt-5">Ajouter une Réservation</h2> 
        <form method="post" action="crudReservation.php"> 
            <input type="hidden" name="action" value="add"> 
           
            <div class="form-group"> 
                <label for="numChambre">Numéro de Chambre :</label> 
                <input type="text" class="form-control" id="" name="numChambre"> 
            </div> 
            <div class="form-group"> 
                <label for="cin">CIN:</label> 
                <input type="text" class="form-control" id="cin" name="cin"> 
            </div> 
            <div class="form-group"> 
                <label for="typeChambre">Type de Chambre:</label> 
                <select class="form-control" id="typeChambre" name="typeChambre"> 
                    <option value="single">Single</option> 
                    <option value="double">Double</option> 
                    <option value="triple">Triple</option> 
                </select> 
            </div> 
            <div class="form-group"> 
                <label for="dateArrivee">Date d'Arrivée:</label> 
                <input type="date" class="form-control" id="dateArrivee" name="dateArrivee"> 
            </div> 
            <div class="form-group"> 
                <label for="dateDepart">Date de Départ:</label> 
                <input type="date" class="form-control" id="dateDepart" name="dateDepart"> 
            </div> 
            <button type="submit" class="btn btn-primary">Réserver</button> 
        </form> 
 
        <h2 class="mt-5">Modifier une Réservation</h2> 
        <form method="post" action="crudReservation.php"> 
            <input type="hidden" name="action" value="edit"> 
            <div class="form-group"> 
                <label for="numReservation">Numéro de Réservation:</label> 
                <input type="text" class="form-control" id="numReservation" name="numReservation"> 
            </div> 
            <div class="form-group"> 
                <label for="numChambre">Numéro de Chambre :</label> 
                <input type="text" class="form-control" id="" name="numChambre"> 
            </div>
            <div class="form-group"> 
                <label for="cin">CIN:</label> 
                <input type="text" class="form-control" id="cin" name="cin"> 
            </div> 
            <div class="form-group"> 
                <label for="typeChambre">Type de Chambre:</label> 
                <select class="form-control" id="typeChambre" name="typeChambre"> 
                    <option value="single">Single</option> 
                    <option value="double">Double</option> 
                    <option value="triple">Triple</option> 
                </select> 
            </div> 
            <div class="form-group"> 
                <label for="dateArrivee">Date d'Arrivée:</label> 
                <input type="date" class="form-control" id="dateArrivee" name="dateArrivee"> 
            </div> 
            <div class="form-group"> 
                <label for="dateDepart">Date de Départ:</label> 
                <input type="date" class="form-control" id="dateDepart" name="dateDepart"> 
            </div> 
            <button type="submit" class="btn btn-secondary">Modifier</button> 
        </form> 
 
        <h2 class="mt-5">Supprimer une Réservation</h2> 
        <form method="post" action="crudReservation.php"> 
            <input type="hidden" name="action" value="delete"> 
            <div class="form-group"> 
                <label for="numReservation">Numéro de Réservation:</label> 
                <input type="text" class="form-control" id="numReservation" name="numReservation"> 
            </div> 
            <button type="submit" class="btn btn-danger">Supprimer</button> 
        </form> 
 
        <h2 class="mt-5">Liste des Réservations</h2> 
        <table class="table table-bordered"> 
            <thead> 
                <tr> 
                    <th>Numéro de Réservation</th> 
                    <th>Numéro de Chambre</th>
                    <th>CIN</th> 
                    <th>Type de Chambre</th> 
                    <th>Date d'Arrivée</th> 
                    <th>Date de Départ</th> 
                </tr> 
            </thead> 
            <tbody> 
                <?php 
                $reservation = $result->fetchAll(PDO::FETCH_ASSOC); 
                foreach ($reservation as $row) { 
                    echo "<tr>"; 
                    echo "<td>" . $row["numReservation"] . "</td>"; 
                    echo "<td>" . $row["numChambre"] . "</td>";
                    echo "<td>" . $row["cin"] . "</td>"; 
                    echo "<td>" . $row["typeChambre"] . "</td>"; 
                    echo "<td>" . $row["dateArrivee"] . "</td>"; 
                    echo "<td>" . $row["dateDepart"] . "</td>"; 
                    echo "</tr>"; 
                } 
                ?> 
            </tbody> 
        </table> 
    </div>
    <footer class="bg-dark text-light py-4">
        <div class="container">
            <p class="text-center">© 2024 The Perfect VACAY . Tous droits réservés.</p>
        </div>
    </footer>
 
   
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script> 
</body> 
</html> 
 
``