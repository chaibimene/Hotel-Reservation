<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Accueil - Réservation d'hôtel</title>
  
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
 
</head>
<body>
    <header class="bg-dark text-light py-4">
        <div class="container">
            <h1 class="display-4">The Perfect VACAY</h1>

        </div>
    </header>
    
    <section class="py-5">
        <div class="container">
            <div class="row">
               <div class="col-md-4">
                  <h2>Réserver un hôtel</h2>
                 <p>Choisissez parmi une sélection d'hôtels de qualité et réservez votre séjour dès aujourd'hui.</p>
                <div class="d-flex justify-content-between">
                    <button class="btn btn-primary" onclick="location.href='signup.php'">S'inscrire</button>
                    <button class="btn btn-secondary ml-2" onclick="location.href='signin.php'">Se connecter</button>
                    <button class="btn btn-info ml-2" onclick="location.href='espaceExtranet.php'">Espace Extranet</button>
                 </div>
                </div>

                <div class="col-md-8">
                    <h2>Contactez-nous</h2>
                    <form>
                        <div class="form-group">
                            <label for="name">Nom</label>
                            <input type="text" class="form-control" id="name" placeholder="Entrez votre nom">
                        </div>
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" placeholder="Entrez votre email">
                        </div>
                        <div class="form-group">
                            <label for="message">Message</label>
                            <textarea class="form-control" id="message" rows="3" placeholder="Entrez votre message"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Envoyer</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <footer class="bg-dark text-light py-4">
        <div class="container">
            <p class="text-center">© 2024 The Perfect VACAY . Tous droits réservés.</p>
        </div>
    </footer>

   
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
