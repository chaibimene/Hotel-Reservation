<?php
session_start();
include 'connexion.php';
include 'Classe_client.php';

if (!isset($_SESSION['admin'])) {
    header("Location: espaceExtranet.php");
    exit();
}

// ajouter client
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "add") {
    $cin = $_POST['cin'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $adresse = $_POST['adresse'];

    $client = new Classe_client($cin, $nom, $prenom, $adresse);

    $sql="INSERT INTO Client (cin,nom,prenom,adresse) VALUES('$cin','$nom','$prenom','$adresse')";
    $result = $connexion->query($sql);
    if ($connexion->exec($sql) === TRUE) {
        echo "Client ajouté avec succès!";
    } else {
        echo "Erreur lors de l'ajout du client.";
    }
   
}

// modifier un client
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "edit") {
    $cin = $_POST['cin'];
    $nom = $_POST['nom'];
    $prenom = $_POST['prenom'];
    $adresse = $_POST['adresse'];

    $sql = "UPDATE Client SET nom='$nom', prenom='$prenom', adresse='$adresse' WHERE cin='$cin'";
    $result = $connexion->query($sql);
    if ($connexion->exec($sql) === TRUE) {
        echo "Client modifié avec succès!";
    } else {
        echo "Erreur lors de la modification du client.";
    }
}

// supprimer un client
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "delete") {
    $cin = $_POST['cin'];

    $sql = "DELETE FROM Client WHERE cin='$cin'";
    $result = $connexion->query($sql);
    if ($connexion->query($sql) === TRUE) {
        echo "Client supprimé avec succès!";
    } else {
        echo "Erreur lors de la suppression du client.";
    }
}

// getting tout les clients
$sql = "SELECT * FROM Client";
$result = $connexion->query($sql);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gérer Clients</title>
 
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container">
                <a class="navbar-brand" href="#">Votre Logo</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="#">Accueil</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Services</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="#">Contact</a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <div class="container mt-5">
        <h1 class="text-center">Gérer Clients</h1>

        <div class="row mt-5">
            <div class="col-md-4">
                <form method="post" action="crudClient.php">
                    <input type="hidden" name="action" value="add">
                    <div class="form-group">
                        <label for="cin">CIN:</label>
                        <input type="text" class="form-control" id="cin" name="cin">
                    </div>
                    <div class="form-group">
                        <label for="nom">Nom:</label>
                        <input type="text" class="form-control" id="nom" name="nom">
                    </div>
                    <div class="form-group">
                        <label for="prenom">Prénom:</label>
                        <input type="text" class="form-control" id="prenom" name="prenom">
                    </div>
                    <div class="form-group">
                        <label for="adresse">Adresse:</label>
                        <input type="text" class="form-control" id="adresse" name="adresse">
                    </div>
                    <button type="submit" class="btn btn-primary">Ajouter Client</button>
                </form>
            </div>
            <div class="col-md-4">
                <form method="post" action="crudClient.php">
                    <input type="hidden" name="action" value="edit">
                    <div class="form-group">
                        <label for="cin_edit">CIN:</label>
                        <input type="text" class="form-control" id="cin_edit" name="cin">
                    </div>
                    <div class="form-group">
                        <label for="nom_edit">Nom:</label>
                        <input type="text" class="form-control" id="nom_edit" name="nom">
                    </div>
                    <div class="form-group">
                        <label for="prenom_edit">Prénom:</label>
                        <input type="text" class="form-control" id="prenom_edit" name="prenom">
                    </div>
                    <div class="form-group">
                        <label for="adresse_edit">Adresse:</label>
                        <input type="text" class="form-control" id="adresse_edit" name="adresse">
                    </div>
                    <button type="submit" class="btn btn-success">Modifier Client</button>
                </form>
            </div>
            <div class="col-md-4">
                <form method="post" action="crudClient.php">
                    <input type="hidden" name="action" value="delete">
                    <div class="form-group">
                        <label for="cin_delete">CIN:</label>
                        <input type="text" class="form-control" id="cin_delete" name="cin">
                    </div>
                    <button type="submit" class="btn btn-danger">Supprimer Client</button>
                </form>
            </div>
        </div>

        <hr class="mt-5">

        <h2>Liste des Clients</h2>
        <div class="table-responsive">
            <table class="table">
                <thead class="thead-light">
                    <tr>
                        <th>CIN</th>
                        <th>Nom</th>
                        <th>Prénom</th>
                        <th>Adresse</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $clients = $result->fetchAll(PDO::FETCH_ASSOC);
                    foreach ($clients as $client) {
                        echo "<tr>";
                        echo "<td>" . $client["cin"] . "</td>";
                        echo "<td>" . $client["nom"] . "</td>";
                        echo "<td>" . $client["prenom"] . "</td>";
                        echo "<td>" . $client["adresse"] . "</td>";
                        echo "</tr>";
                    }
                    ?>
                </tbody>
            </table>
        </div>

        <div class="text-center mt-5">
            <button class="btn btn-primary" onclick="location.href='bienvenueAdmin.php'">Revenir à la page Admin</button>
        </div>
    </div>

    <footer class="bg-dark text-light py-4">
        <div class="container">
            <p class="text-center">© 2024 The Perfect VACAY . Tous droits réservés.</p>
        </div>
    </footer>
    
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
