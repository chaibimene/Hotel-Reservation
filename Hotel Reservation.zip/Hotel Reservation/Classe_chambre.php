<?php

 class Classe_chambre {
   public $numChambre;
    public $type;
    public $prix;
    public $dispo;
   

    public function __construct($numChambre, $type, $prix) {
        $this->numChambre = $numChambre;
        $this->type = $type;
        $this->prix = $prix;
    

    }
    public function __toString() {
        return $this->numChambre." ".$this->type." ".$this->prix."\n";
    }

    public function afficher() {
        echo $this->numChambre." ".$this->type." ".$this->prix." \n";
    }
   
}
    




?>