<?php
include 'Classe_reservation.php';
include 'Classe_chambre.php';
include 'Classe_client.php';
include 'connexion.php';
//insert reservation

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "add") {
    $cin = $_POST['cin'];
    $typeChambre = $_POST['typeChambre'];
    $dateArrivee = $_POST['dateArrivee'];
    $dateDepart = $_POST['dateDepart'];
  
    $numChambre = $_POST['numChambre'];
   
    
    $sql = "INSERT INTO Reservation ( cin, numChambre,typeChambre, dateArrivee, dateDepart) VALUES ( '$cin','$numChambre','$typeChambre', '$dateArrivee', '$dateDepart')";
     $result = $connexion->exec($sql);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $numReservation = $_POST['numReservation'];

    $sql = "SELECT r.numReservation, r.cin, r.numChambre, r.typeChambre, r.dateArrivee, r.dateDepart,
                   c.nom, c.prenom, c.adresse,
                   ch.type AS typeChambre, ch.prix
            FROM Reservation r
            JOIN Client c ON r.cin = c.cin
            JOIN Chambre ch ON r.numChambre = ch.numChambre
            WHERE r.numReservation = :numReservation";
    $stmt = $connexion->prepare($sql);
    $stmt->bindParam(':numReservation', $numReservation, PDO::PARAM_INT);
    $stmt->execute();
    $reservation = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facture</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Facture</h1>
        <?php if (isset($reservation)) { ?>
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Détails de la Réservation</h5>
                    <p><strong>Numéro de Réservation:</strong> <?php echo htmlspecialchars($reservation['numReservation']); ?></p>
                    <p><strong>CIN:</strong> <?php echo htmlspecialchars($reservation['cin']); ?></p>
                    <p><strong>Type de Chambre:</strong> <?php echo htmlspecialchars($reservation['typeChambre']); ?></p>
                    <p><strong>Numéro de Chambre:</strong> <?php echo htmlspecialchars($reservation['numChambre']); ?></p>
                    <p><strong>Date d'Arrivée:</strong> <?php echo htmlspecialchars($reservation['dateArrivee']); ?></p>
                    <p><strong>Date de Départ:</strong> <?php echo htmlspecialchars($reservation['dateDepart']); ?></p>
                    
                    <h5 class="card-title">Détails du Client</h5>
                    <p><strong>Nom:</strong> <?php echo htmlspecialchars($reservation['nom']); ?></p>
                    <p><strong>Prénom:</strong> <?php echo htmlspecialchars($reservation['prenom']); ?></p>
                    <p><strong>Adresse:</strong> <?php echo htmlspecialchars($reservation['adresse']); ?></p>
                    
                    <h5 class="card-title">Détails de la Chambre</h5>
                    <p><strong>Type de Chambre:</strong> <?php echo htmlspecialchars($reservation['typeChambre']); ?></p>
                    <p><strong>Prix:</strong> <?php echo htmlspecialchars($reservation['prix']); ?> Dinars </p>
                </div>
            </div>
        <?php } else { ?>
            <p class="text-danger">Aucune réservation trouvée.</p>
        <?php } ?>
    </div>
    <footer class="bg-dark text-light py-4">
        <div class="container">
            <p class="text-center">© 2024 The Perfect VACAY . Tous droits réservés.</p>
        </div>
    </footer>
  
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
